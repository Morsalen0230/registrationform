let name=document.querySelector('#isName')
let fname=document.querySelector('#fatherName')
let mname=document.querySelector('#motherName')
let sname=document.querySelector('#sisterName')
let form = document.querySelector('form')

let date = document.querySelector('#date');
let container = document.querySelector('.container')
let showdiv = document.querySelector('.showdiv')

let nm= document.querySelector('#NM')
let  fn= document.querySelector('#fN')
let mn= document.querySelector('#MN')
let sn= document.querySelector('#SN')
let gn= document.querySelector('#GN')
let dp= document.querySelector('#DP')
let bd= document.querySelector('#DD')



let counti
let y;
function counter(){

  counti +=1
  if (counti==5) {
    clearInterval(y);
    animate.classList.remove('onlod');
    container.style.display= 'none';
    showdiv.style.display='block'
  }

  //console.log(counti)
}

 


function formsubmit(e){
    e.preventDefault();
  counter();
y=setInterval(counter,100);
counti=0;
   
  animate.classList.add('onlod')
  
  
  nm.innerText= name.value;
  fn.innerText= fname.value;
 mn.innerText= mname.value;
  sn.innerText= sname.value;
  
  bd.innerText= date.value
  
  
  
const radioButtons = document.querySelectorAll('input[type="radio"]');

  let selectedO;
  for (const radioButton of radioButtons) {
    if (radioButton.checked) {
      selectedO = radioButton.value;
      gn.innerText = selectedO;
      //console.log(selectedO)

      break;
    }
  }


const checkButtons = document.querySelectorAll('input[type="checkbox"]');


let selectedP;
for (const cButton of checkButtons) {
  if (cButton.checked) {
    selectedP = cButton.value;
    dp.innerText = selectedP;
    //console.log(selectedP)

    break;
  }
}
}




let animate = document.querySelector('#animat')

window.addEventListener('load',()=>{
   animate.classList.remove('onlod')
})